<?php

# lifted from http://www.php.net/manual/en/class.pdo.php#89019

class PH_PDO extends PDO
{
    public function __construct($file = '/etc/secondlook/phdb_settings.ini')
    {
        if (!$settings = parse_ini_file($file, TRUE)) throw new exception('Unable to open ' . $file . '.');
        $dsn = 'mysql' .
        ':host=' . $settings['database']['host'] .
        ((!empty($settings['database']['port'])) ? (';port=' . $settings['database']['port']) : '') .
        ';dbname=' . $settings['database']['dbname'];
       
       if (empty($settings['database']['password']))
       	  parent::__construct($dsn, $settings['database']['username'], '', array(PDO::ATTR_PERSISTENT => true));
       else
	  parent::__construct($dsn, $settings['database']['username'], $settings['database']['password'], array(PDO::ATTR_PERSISTENT => true));
    }
}
?>
