#!/bin/bash
LOGFILE=/home/secondlook_feeds/import_pagehashes.log
if [[ $1 =~ \.sql_log\.bz2$ ]]
then
	echo "`date` Importing $1" >> $LOGFILE
	bzcat $1 | mysql -usecondlook_rw pagehash &> /tmp/ph_import_err
	ph_import_rv=$?
	cat /tmp/ph_import_err >> $LOGFILE
	if [[ "$ph_import_rv" == "0" ]]
	then
		echo "`date` $1 import complete" >> $LOGFILE
	else
		echo "`date` $1 import error" >> $LOGFILE
		cat /tmp/ph_import_err | mail -s "Pagehash Import Error: $1" root
	fi
else
	echo "`date` Skipping $1" >> $LOGFILE
fi
