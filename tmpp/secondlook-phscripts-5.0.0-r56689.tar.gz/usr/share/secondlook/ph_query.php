<?php

# Reminder: make sure Apache's MaxKeepAliveRequests directive is set nice and
# high.

require 'phdb_config.php';

try {

$dbh = new PH_PDO();
$result_str = "";

$page_stmt = $dbh->prepare(
	"SELECT page.filehash
	 FROM page
	 WHERE page.hash   = unhex(:hash) AND
	       page.offset = :offset");

$file_stmt = $dbh->prepare(
	"SELECT pkg.hash, pkg.name, file.hash, file.name
	 FROM pkg, file
	 WHERE file.hash    = :hash AND
	       file.pkghash = pkg.hash
	 ORDER BY pkg.hash ASC, pkg.name ASC, file.hash ASC, file.name ASC
	 LIMIT 10");

# POST parameter 'q' is expected to have the form: hash1,offset1;hash2,offset2;...

$query_pairs = explode(";", $_POST['q']);
foreach ($query_pairs as $qp) {
	$temp = explode(",", $qp);
	if (count($temp) != 2) {
		continue;
	}
	$pagehash = $temp[0];
	$pageoffset = $temp[1];
	$result_str = $result_str . $pagehash . "\n";
	$result_str = $result_str . $pageoffset . "\n";

	$page_stmt->bindParam(':hash', $pagehash, PDO::PARAM_STR);
	$page_stmt->bindParam(':offset', $pageoffset, PDO::PARAM_INT);
	$page_stmt->execute();
	$page_result = $page_stmt->fetchall();

	foreach ($page_result as $page_row) {
		$file_stmt->bindParam(':hash', $page_row[0], PDO::PARAM_STR);
		$file_stmt->execute();
		$file_result = $file_stmt->fetchall();

		foreach ($file_result as $file_row) {
			$result_str = $result_str . bin2hex($file_row[0]) . " " . $file_row[1] . "\n";
			$result_str = $result_str . bin2hex($file_row[2]) . " " . $file_row[3] . "\n";
		}
	}
	$result_str = $result_str . "-\n";
}

header("Content-Type: text/plain; charset=UTF-8");
header("Content-Length: " . strlen($result_str)); 

echo $result_str;

} catch(PDOException $e) {
	echo $e->getMessage();
}

?>
